
define(function(require, exports, module) {

"use strict";

module.exports = {
    _default: {
        text: "",
        isLine: false
    }
};

});
