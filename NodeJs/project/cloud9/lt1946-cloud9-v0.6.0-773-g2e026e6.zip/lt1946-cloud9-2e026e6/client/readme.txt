IMPORTANT: IF you update requireJS, please append the "text" plugin to the 
           bottom of the 'require.js' file. This makes sure that ACE gets loaded 
           properly.