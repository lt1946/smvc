var i = 0
console.log("HIII");
setInterval(function() {
    console.log(i++);
}, 1000)